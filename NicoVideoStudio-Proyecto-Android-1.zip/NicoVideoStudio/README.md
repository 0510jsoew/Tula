# Nico Video Studio

Proyecto Android nativo inicial para videos de figuras de palitos con Nico.

## Funciones incluidas
- Interfaz en español.
- Tema y duración objetivo.
- Generador local de borrador de guion.
- Narración usando Text-to-Speech del dispositivo.
- Vista previa animada básica de Nico dibujado por código.
- GitHub Actions para compilar una APK de depuración.

## Limitaciones
Esta versión inicial **no exporta MP4** ni genera automáticamente un video final de 5–10 minutos. La animación es una vista previa sencilla. Para un generador de videos real falta añadir captura de fotogramas, mezcla de audio, renderizado MP4 y pruebas en Android.

## Compilación
El workflow `.github/workflows/build.yml` compila al hacer push a `main` o `principal`, o manualmente desde Actions. El artefacto se llama `Nico-Video-Studio-APK`.

Requisitos: JDK 17, Android SDK Platform 35, Build Tools 35.0.0 y Gradle 8.9.
